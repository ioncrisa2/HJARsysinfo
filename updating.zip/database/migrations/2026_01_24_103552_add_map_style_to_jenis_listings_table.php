<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('jenis_listings', function (Blueprint $table) {
            $table->unsignedSmallInteger('sort_order')->default(0);
            $table->boolean('is_active')->default(true);
            $table->string('badge_color', 20)->nullable()->after('name');
            $table->string('marker_icon_url')->nullable()->after('badge_color');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('jenis_listings', function (Blueprint $table) {
            $table->dropColumn(['badge_color', 'marker_icon_url','sort_order','is_active']);
        });
    }
};
