<?php

namespace App\Filament\Resources\BentukTanahResource\Pages;

use App\Filament\Resources\BentukTanahResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateBentukTanah extends CreateRecord
{
    protected static string $resource = BentukTanahResource::class;
}
