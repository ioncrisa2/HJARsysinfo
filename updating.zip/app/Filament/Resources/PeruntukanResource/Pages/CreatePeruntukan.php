<?php

namespace App\Filament\Resources\PeruntukanResource\Pages;

use App\Filament\Resources\PeruntukanResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePeruntukan extends CreateRecord
{
    protected static string $resource = PeruntukanResource::class;
}
