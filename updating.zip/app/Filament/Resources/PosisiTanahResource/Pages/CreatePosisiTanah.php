<?php

namespace App\Filament\Resources\PosisiTanahResource\Pages;

use App\Filament\Resources\PosisiTanahResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePosisiTanah extends CreateRecord
{
    protected static string $resource = PosisiTanahResource::class;
}
