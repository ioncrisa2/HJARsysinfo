<?php

namespace App\Filament\Resources\JenisObjekResource\Pages;

use App\Filament\Resources\JenisObjekResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateJenisObjek extends CreateRecord
{
    protected static string $resource = JenisObjekResource::class;
}
