<?php

namespace App\Filament\Clusters;

use Filament\Clusters\Cluster;

class MasterData extends Cluster
{
    protected static ?string $navigationIcon = 'heroicon-o-squares-2x2';
}
