<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JenisListing extends Model
{
    protected $fillable = [
        'slug',
        'name',
        'sort_order',
        'badge_color',
        'marker_icon_url'
    ];

    /**
     * Convenience helper for Select options: [slug => name]
     */
    public static function options(): array
    {
        return static::query()
            ->orderBy('name')
            ->pluck('name', 'slug')
            ->all();
    }
}
