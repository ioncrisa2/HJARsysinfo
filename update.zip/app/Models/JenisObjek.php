<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JenisObjek extends Model
{
    protected $table = 'master_jenis_objek';

    protected $fillable = ['slug', 'name', 'sort_order', 'is_active'];

    protected $casts = [
        'sort_order' => 'integer',
        'is_active'  => 'boolean',
    ];

    public static function options(bool $onlyActive = true): array
    {
        $q = static::query()->orderBy('sort_order')->orderBy('name');
        if ($onlyActive) $q->where('is_active', true);

        return $q->pluck('name', 'slug')->all();
    }
}
