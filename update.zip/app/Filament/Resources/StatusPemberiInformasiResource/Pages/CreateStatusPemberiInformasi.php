<?php

namespace App\Filament\Resources\StatusPemberiInformasiResource\Pages;

use App\Filament\Resources\StatusPemberiInformasiResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateStatusPemberiInformasi extends CreateRecord
{
    protected static string $resource = StatusPemberiInformasiResource::class;
}
