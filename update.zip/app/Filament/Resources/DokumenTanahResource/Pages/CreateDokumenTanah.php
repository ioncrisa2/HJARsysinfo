<?php

namespace App\Filament\Resources\DokumenTanahResource\Pages;

use App\Filament\Resources\DokumenTanahResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDokumenTanah extends CreateRecord
{
    protected static string $resource = DokumenTanahResource::class;
}
