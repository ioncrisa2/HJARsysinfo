<?php

namespace App\Filament\Resources\TopografiResource\Pages;

use App\Filament\Resources\TopografiResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTopografi extends CreateRecord
{
    protected static string $resource = TopografiResource::class;
}
