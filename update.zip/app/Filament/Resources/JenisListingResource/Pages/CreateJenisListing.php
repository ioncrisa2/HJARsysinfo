<?php

namespace App\Filament\Resources\JenisListingResource\Pages;

use App\Filament\Resources\JenisListingResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateJenisListing extends CreateRecord
{
    protected static string $resource = JenisListingResource::class;
}
