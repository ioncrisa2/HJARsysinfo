<?php

// translations for Teguh02/IndonesiaTerritoryForms
return [
    'section_title' => "Indonesia Territory Forms",
    'province' => "Province",
    'city' => "City",
    'district' => "District",
    'sub_district' => "Subdistrict",
    'postal_code' => "Postal Code",
];
