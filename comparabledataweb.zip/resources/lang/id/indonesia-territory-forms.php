<?php

// indonesian translations for Teguh02/IndonesiaTerritoryForms
return [
    'section_title' => "Formulir Wilayah Indonesia",
    'province' => "Provinsi",
    'city' => "Kota",
    'district' => "Kecamatan",
    'sub_district' => "Kelurahan",
    'postal_code' => "Kode Pos",
];
