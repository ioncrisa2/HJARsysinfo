<?php return array (
  'anourvalar/eloquent-serialize' => 
  array (
    'aliases' => 
    array (
      'EloquentSerialize' => 'AnourValar\\EloquentSerialize\\Facades\\EloquentSerializeFacade',
    ),
  ),
  'bezhansalleh/filament-shield' => 
  array (
    'aliases' => 
    array (
      'FilamentShield' => 'BezhanSalleh\\FilamentShield\\Facades\\FilamentShield',
    ),
    'providers' => 
    array (
      0 => 'BezhanSalleh\\FilamentShield\\FilamentShieldServiceProvider',
    ),
  ),
  'blade-ui-kit/blade-heroicons' => 
  array (
    'providers' => 
    array (
      0 => 'BladeUI\\Heroicons\\BladeHeroiconsServiceProvider',
    ),
  ),
  'blade-ui-kit/blade-icons' => 
  array (
    'providers' => 
    array (
      0 => 'BladeUI\\Icons\\BladeIconsServiceProvider',
    ),
  ),
  'devonab/filament-easy-footer' => 
  array (
    'aliases' => 
    array (
      'FilamentEasyFooter' => 'Devonab\\FilamentEasyFooter\\Facades\\EasyFooter',
    ),
    'providers' => 
    array (
      0 => 'Devonab\\FilamentEasyFooter\\EasyFooterServiceProvider',
    ),
  ),
  'dotswan/filament-map-picker' => 
  array (
    'aliases' => 
    array (
      'MapPicker' => 'Dotswan\\MapPicker\\Facades\\MapPicker',
    ),
    'providers' => 
    array (
      0 => 'Dotswan\\MapPicker\\MapPickerServiceProvider',
    ),
  ),
  'eightcedars/filament-inactivity-guard' => 
  array (
    'providers' => 
    array (
      0 => 'EightCedars\\FilamentInactivityGuard\\FilamentInactivityGuardServiceProvider',
    ),
  ),
  'filament/actions' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Actions\\ActionsServiceProvider',
    ),
  ),
  'filament/filament' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\FilamentServiceProvider',
    ),
  ),
  'filament/forms' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Forms\\FormsServiceProvider',
    ),
  ),
  'filament/infolists' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Infolists\\InfolistsServiceProvider',
    ),
  ),
  'filament/notifications' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Notifications\\NotificationsServiceProvider',
    ),
  ),
  'filament/support' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Support\\SupportServiceProvider',
    ),
  ),
  'filament/tables' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Tables\\TablesServiceProvider',
    ),
  ),
  'filament/widgets' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Widgets\\WidgetsServiceProvider',
    ),
  ),
  'flowframe/laravel-trend' => 
  array (
    'aliases' => 
    array (
      'Trend' => 'Flowframe\\Trend\\TrendFacade',
    ),
    'providers' => 
    array (
      0 => 'Flowframe\\Trend\\TrendServiceProvider',
    ),
  ),
  'hydrat/filament-table-layout-toggle' => 
  array (
    'aliases' => 
    array (
      'TableLayoutToggle' => 'Hydrat\\TableLayoutToggle\\Facades\\TableLayoutToggle',
    ),
    'providers' => 
    array (
      0 => 'Hydrat\\TableLayoutToggle\\TableLayoutToggleServiceProvider',
    ),
  ),
  'intervention/image' => 
  array (
    'aliases' => 
    array (
      'Image' => 'Intervention\\Image\\Facades\\Image',
    ),
    'providers' => 
    array (
      0 => 'Intervention\\Image\\ImageServiceProvider',
    ),
  ),
  'jacobtims/filament-logger' => 
  array (
    'aliases' => 
    array (
      'FilamentLogger' => 'Z3d0X\\FilamentLogger\\Facades\\FilamentLogger',
    ),
    'providers' => 
    array (
      0 => 'Z3d0X\\FilamentLogger\\FilamentLoggerServiceProvider',
    ),
  ),
  'jeffgreco13/filament-breezy' => 
  array (
    'aliases' => 
    array (
      'FilamentBreezy' => 'Jeffgreco13\\FilamentBreezy\\Facades\\FilamentBreezy',
    ),
    'providers' => 
    array (
      0 => 'Jeffgreco13\\FilamentBreezy\\FilamentBreezyServiceProvider',
    ),
  ),
  'jenssegers/agent' => 
  array (
    'aliases' => 
    array (
      'Agent' => 'Jenssegers\\Agent\\Facades\\Agent',
    ),
    'providers' => 
    array (
      0 => 'Jenssegers\\Agent\\AgentServiceProvider',
    ),
  ),
  'joshembling/image-optimizer' => 
  array (
    'aliases' => 
    array (
      'ImageOptimizer' => 'Joshembling\\ImageOptimizer\\Facades\\ImageOptimizer',
    ),
    'providers' => 
    array (
      0 => 'Joshembling\\ImageOptimizer\\ImageOptimizerServiceProvider',
    ),
  ),
  'kirschbaum-development/eloquent-power-joins' => 
  array (
    'providers' => 
    array (
      0 => 'Kirschbaum\\PowerJoins\\PowerJoinsServiceProvider',
    ),
  ),
  'laravel/pail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Pail\\PailServiceProvider',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/sanctum' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sanctum\\SanctumServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'livewire/livewire' => 
  array (
    'aliases' => 
    array (
      'Livewire' => 'Livewire\\Livewire',
    ),
    'providers' => 
    array (
      0 => 'Livewire\\LivewireServiceProvider',
    ),
  ),
  'maatwebsite/excel' => 
  array (
    'aliases' => 
    array (
      'Excel' => 'Maatwebsite\\Excel\\Facades\\Excel',
    ),
    'providers' => 
    array (
      0 => 'Maatwebsite\\Excel\\ExcelServiceProvider',
    ),
  ),
  'nben/filament-record-nav' => 
  array (
    'aliases' => 
    array (
      'FilamentRecordNav' => 'Nben\\FilamentRecordNav\\Facades\\FilamentRecordNav',
    ),
    'providers' => 
    array (
      0 => 'Nben\\FilamentRecordNav\\FilamentRecordNavServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'pelmered/filament-money-field' => 
  array (
    'providers' => 
    array (
      0 => 'Pelmered\\FilamentMoneyField\\FilamentMoneyFieldServiceProvider',
    ),
  ),
  'pestphp/pest-plugin-laravel' => 
  array (
    'providers' => 
    array (
      0 => 'Pest\\Laravel\\PestServiceProvider',
    ),
  ),
  'promethys/revive' => 
  array (
    'aliases' => 
    array (
      'FilamentRevive' => 'Promethys\\FilamentRevive\\Facades\\FilamentRevive',
    ),
    'providers' => 
    array (
      0 => 'Promethys\\FilamentRevive\\FilamentReviveServiceProvider',
    ),
  ),
  'propaganistas/laravel-phone' => 
  array (
    'providers' => 
    array (
      0 => 'Propaganistas\\LaravelPhone\\PhoneServiceProvider',
    ),
  ),
  'pxlrbt/filament-excel' => 
  array (
    'providers' => 
    array (
      0 => 'pxlrbt\\FilamentExcel\\FilamentExcelServiceProvider',
    ),
  ),
  'ryangjchandler/blade-capture-directive' => 
  array (
    'aliases' => 
    array (
      'BladeCaptureDirective' => 'RyanChandler\\BladeCaptureDirective\\Facades\\BladeCaptureDirective',
    ),
    'providers' => 
    array (
      0 => 'RyanChandler\\BladeCaptureDirective\\BladeCaptureDirectiveServiceProvider',
    ),
  ),
  'spatie/laravel-activitylog' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Activitylog\\ActivitylogServiceProvider',
    ),
  ),
  'spatie/laravel-permission' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Permission\\PermissionServiceProvider',
    ),
  ),
  'teguh02/indonesia-territory-forms' => 
  array (
    'aliases' => 
    array (
      'IndonesiaTerritoryForms' => 'Teguh02\\IndonesiaTerritoryForms\\Facades\\IndonesiaTerritoryForms',
    ),
    'providers' => 
    array (
      0 => 'Teguh02\\IndonesiaTerritoryForms\\IndonesiaTerritoryFormsServiceProvider',
    ),
  ),
  'webbingbrasil/filament-maps' => 
  array (
    'providers' => 
    array (
      0 => 'Webbingbrasil\\FilamentMaps\\FilamentMapsProvider',
    ),
  ),
  'ysfkaya/filament-phone-input' => 
  array (
    'providers' => 
    array (
      0 => 'Ysfkaya\\FilamentPhoneInput\\FilamentPhoneInputServiceProvider',
    ),
  ),
  'z3d0x/filament-logger' => 
  array (
    'aliases' => 
    array (
      'FilamentLogger' => 'Z3d0X\\FilamentLogger\\Facades\\FilamentLogger',
    ),
    'providers' => 
    array (
      0 => 'Z3d0X\\FilamentLogger\\FilamentLoggerServiceProvider',
    ),
  ),
);