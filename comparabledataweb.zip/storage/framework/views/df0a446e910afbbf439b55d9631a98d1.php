<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('filament-inactivity-guard::session-guard');

$__html = app('livewire')->mount($__name, $__params, 'lw-4059438159-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?><?php /**PATH C:\Users\zyoha\Herd\comparabledataweb\storage\framework\views/456e59d2425481d71e0530ff39b1fec3.blade.php ENDPATH**/ ?>